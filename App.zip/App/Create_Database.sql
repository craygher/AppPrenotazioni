create database prenotazioni;
use prenotazioni;
create table classe(
	classe varchar(10) primary key 
);
create table campo(
	id_campo int auto_increment primary key
);
create table occupazione_campo(
	id int auto_increment primary key,
    classe varchar(10),
    foreign key (classe) references classe(classe),
    id_campo int,
    foreign key(id_campo) references campo(id_campo),
    orario_occupazione datetime
);
insert into campo() values 
(1),
(2),
(3),
(4);

insert into classe(classe) VALUES
("1A"),
("2A"),
("3A"),
("4A"),
("5A"),
("1B"),
("2B"),
("3B"),
("4B"),
("5B"),
("1C"),
("2C"),
("3C"),
("4C"),
("5C"),
("1D"),
("2D"),
("3D"),
("4D"),
("5D");