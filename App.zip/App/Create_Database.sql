create database prenotazioni;
use prenotazioni;
create table classe(
	classe varchar(10) primary key 
);
create table campo(
	id_campo int auto_increment primary key
);
create table occupazione_campo(
	id int auto_increment primary key,
    classe varchar(10),
    foreign key (classe) references classe(classe),
    id_campo int,
    foreign key(id_campo) references campo(id_campo),
    orario_occupazione datetime
);
insert into campo() values (1);
insert into campo() values(2);
insert into campo() values(3);
insert into campo() values(4);
